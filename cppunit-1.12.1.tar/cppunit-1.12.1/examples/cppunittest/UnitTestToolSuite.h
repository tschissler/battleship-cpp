#ifndef CPPUNITTEST_UNITTESTTOOLSUITE_H
#define CPPUNITTEST_UNITTESTTOOLSUITE_H

#include <cppunit/Portability.h>
#include <string>

inline std::string unitTestToolSuiteName()
{
  return "UnitTestTool";
}

#endif // CPPUNITTEST_UNITTESTTOOLSUITE_H
